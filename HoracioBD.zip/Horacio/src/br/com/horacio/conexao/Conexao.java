package br.com.horacio.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexao {
	
	public static Connection abrirConexao() 
	{
		Connection con =  null;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
			con = DriverManager.getConnection(url);
			System.out.println("Abriu");
			
		}catch(ClassNotFoundException e)
		{
			System.out.println(e.getMessage() + "Erro no envio dos dados");
			
		}catch(SQLException e )
		{
			System.out.println(e.getMessage() + "Erro no envio dos dados");
			
		}catch(Exception e)
		{
			System.out.println(e.getMessage() + "Erro no envio dos dados");
		}
		return con;
	}
	
	
	public static void fecharConexao(Connection con) {
		
		try {
			con.close();
			System.out.println();
			
		}catch(SQLException e)
		{
		
		}
		
		
		
		
		
		
		
	}
	
	
	
	
	

}
