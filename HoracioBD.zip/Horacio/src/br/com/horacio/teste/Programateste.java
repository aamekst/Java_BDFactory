package br.com.horacio.teste;

import br.com.horacio.beans.Pessoa;

public class Programateste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pessoa pessoa = new Pessoa();
		
		pessoa.setEndereco("Rua papai noetl 123");
		pessoa.setNome("Papai noel");
		
		pessoa.mostrarAtributos();
	}

}
