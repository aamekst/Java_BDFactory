package br.com.horacio.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import br.com.horacio.beans.Pessoa;

public class PessoaDAO {
	
 private Connection con;
	
	public Connection getCon() {
		return con;
	}
	
	public void setCon(Connection con) {
		this.con = con;
	}
 
	public String inserir(Pessoa pessoa) {
		String sql = "insert into pessoa(nome, endereco) values (?,?)";
		try {
			PreparedStatement ps = getCon().prepareCall(sql);
			ps.setString(2, pessoa.getEndereco());
			ps.setString(1, pessoa.getNome());
			
			if(ps.executeUpdate()>0) {
				return "Inserido";
				
			}else {
				return "erro ao inserir";
			}
		}catch(SQLException e) {
			return e.getMessage();
		}
	}

}
